#pragma once
/*
	Liste des type de laser disponible de base dans le jeu. On peut en ajouter ou les modifier au besoin.
*/
enum class TypeLaser {
	JOUEUR = '|',
	EXTRATERRESTRE = '*'
};
