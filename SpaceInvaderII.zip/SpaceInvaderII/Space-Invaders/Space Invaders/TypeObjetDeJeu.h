#pragma once

/*
	Liste des types d'objets de jeux disponible dans le programme. On peut en ajouter au besoin.
*/
enum class TypeObjetDeJeu {
	VAISSEAU,
	EXTRATERRESTRE,
	LASER
};