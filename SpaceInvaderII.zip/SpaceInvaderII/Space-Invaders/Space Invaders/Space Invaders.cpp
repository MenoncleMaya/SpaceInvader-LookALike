

#include <iostream>
#include "Partie.h"
using namespace std;

int main() {
	//D�mare une seule partie, la joue et la supprime imm�diatement lorsqu'elle est termin�e
	Partie* partie = new Partie();
	partie->debuter();
	delete partie;
	return 0;
}