
#pragma once
/*
	Liste des touches de d�placements disponibles pour le d�placement du vaisseau
	du vaisseau. On peut les modifier.
*/
enum class Direction {
	GAUCHE,
	DROITE
};