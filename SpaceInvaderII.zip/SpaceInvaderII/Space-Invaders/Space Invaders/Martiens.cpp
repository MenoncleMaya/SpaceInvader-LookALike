

#include "Martiens.h"
#include <random>
Martien::Martien(Coord coord, char apparence, unsigned short valeurPoints) : Extraterrestes(coord, apparence, valeurPoints), toggle(rand() % 2) {}

void Martien::deplacer() {
	this->effacer();
	this->coord.setX(this->coord.getX() + (toggle ? 1 : -1));
	toggle = !toggle;
	this->afficher();
}


//Ajout
void Martien::foward() {
	this->effacer();
	this->coord.setY(this->coord.getY() + 1);
	this->afficher();
}