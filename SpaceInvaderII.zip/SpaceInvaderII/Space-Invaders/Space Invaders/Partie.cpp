#include "Partie.h"
#include "Martiens.h"
#include "Extraterrestes.h"
#include "Laser.h"
#include "Vaisseau.h"
#include "UIKit.h"
#include "ObjetDeJeu.h"

#include <iostream>
#include <conio.h>
#include <thread>
#include <future>
#include <vector>
#include <ctime>
#include <Windows.h>

using namespace std;

void Partie::debuter()
{
#pragma region variable



	//Constante
	const string EASY = "EASY";
	const string MEDIUM = "MEDIUM";
	const string HARD = "HARD";
	const string GAME_PAUSED = "GAME PAUSED";
	const string GAME_UNPAUSED = "           ";
	const string PRESS_ENTER = "Press enter to continue";
	const string PRESS_ENTER_EXIT = "                        ";

	//Variables
	int highScore = 0;
	int pointValue = 100;
	int difficultyTime = 1;
	int difficultyScore = 1;
	bool gameLoop = true;
	string highScoreDifficulty{ "" };

	COORD intro;
	intro.X = 20;
	intro.Y = 2;

	COORD coord;
	coord.X = 8;
	coord.Y = 0;

	COORD pause;
	pause.X = 30;
	pause.Y = 22;

	COORD cExit;
	cExit.X = 24;
	cExit.Y = 23;

	//Signature
	bool ennemyToFar(vector<Martien> vec, Vaisseau vaisseau);
	void UpdateScore(int score, COORD coord);
	bool checkEnnemy(vector<Martien> vec);
	void PAUSE(COORD pause, string GAME_PAUSED, string GAME_UNPAUSED, string PRESS_ENTER, string PRESS_ENTER_EXIT, COORD cExit);
	int iValidation();


	//CONST INT
	const int POSITION_X_MAX = 50;
	const int POSITION_X_MIN = 10;
	const int POSITION_Y_MAX = 7;
	const int POSITION_Y_MIN = 3;

	//Faire apparaitre le vaisseau
	Coord coordonneesDepartVaisseau(30, 20);
	Coord limiteMouvementGauche(8, 20);
	Coord limiteMouvementDroite(52, 20);
	char apparenceDuVaisseau = 'A';
	char apparenceDesEnnemis = 'O';

	//UI
	UIKit::curseurVisible(false);
	UIKit::setDimensionFenetre(0, 0, 70, 30);
#pragma endregion
	while (gameLoop) { //Game loop
		//Variable local
		bool partieTermine = false;
		bool partieGagne = false;
		bool moveLasers = true;
		bool difficultySelection = true;

		//Afficher le Menu
		system("cls"); //Efface l'�cran
		cout << "Welcome to SpaceInvaders II        (we totally own the rights)" << endl << endl << "HighScore : " << highScore;
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), intro);
		cout << "Difficulty : " << highScoreDifficulty << endl << endl;
		cout << "Selectionner votre difficulte" << endl << "1 -- easy\n2 -- medium\n3 -- hard\n4 -- EXIT\n\n";
		int choix = iValidation(); //Enregistre le choix de difficult�s du joueur

		system("cls"); //Efface l'�cran

		//Affiche la bonne difficult�s dans le menu et modifie les param�tres de jeu en cons�quence
		switch (choix)
		{
		case 1: //Facile
			difficultyTime = 3;
			difficultyScore = choix;
			break;
		case 2: //Moyen
			difficultyTime = 2;
			difficultyScore = choix;
			break;
		case 3: //Difficile
			difficultyTime = 1;
			difficultyScore = choix;
			break;
		case 4: //Quitter
			cout << "Goodbye\n";
			gameLoop = false;
			system("pause");
			break;
		default: //Default
			break;
		}
		if (gameLoop) {

			SetCursorPos(0, 0); //Met le curseur en 0,0
			cout << "Score : 0"; //Affiche le score

			Vaisseau vaisseau(apparenceDuVaisseau, coordonneesDepartVaisseau, limiteMouvementGauche, limiteMouvementDroite); //Cr�er un vaisseau

			//Variable
			int score = 0;
			int enemyKilled = 0;

			//Vecteurs
			vector<Laser> lasers;
			vector<Laser> lasersEnemy;
			vector<Martien> martiens;

			//Clock controle
			srand(time(nullptr));
			clock_t start = clock();
			clock_t enemyClock = clock();
			clock_t ennemyFoward = clock();

			//FaireSpawner 4 martiens en debut de partie
			for (int i = 0; i < 4; i++) {
				Coord enemyPosition(rand() % (POSITION_X_MAX - POSITION_X_MIN + 1) + POSITION_X_MIN, rand() % (POSITION_Y_MAX - POSITION_Y_MIN) + POSITION_Y_MAX);
				Martien martien(enemyPosition, apparenceDesEnnemis, pointValue);
				martiens.push_back(martien);
			}
			do {

				if (martiens.size() < 15 + enemyKilled && martiens.size() != 0) //Si la partie est lanc�e
				{
					//R�cup�rer la touche appuy�e par l'utilisateur
					//Effectuer action en fonction de la touche appuy� par l'utilisateur
					//Ici on peut soit d�placer le vaiseau � gauche ou � droite, soit tirer un laser
					if (GetAsyncKeyState(VK_LEFT)) {
						vaisseau.deplacer(Direction::GAUCHE);
					}
					else if (GetAsyncKeyState(VK_RIGHT)) {
						vaisseau.deplacer(Direction::DROITE);
					}
					else if (GetAsyncKeyState(VK_SPACE)) {
						Laser laser(vaisseau.getCoord(), TypeLaser::JOUEUR);
						lasers.push_back(laser);
					}
					else if (GetAsyncKeyState(VK_ESCAPE)) {
						PAUSE(pause, GAME_PAUSED, GAME_UNPAUSED, PRESS_ENTER, PRESS_ENTER_EXIT, cExit);
					}
					//V�rifier collision entre laser et ennemis
					for (int i = 0; i < martiens.size(); i++)
					{
						for (int j = 0; j < lasers.size(); j++)
						{
							if (martiens[i].isActif() && lasers[j].isActif()) {
								if (martiens[i].detecterCollision(lasers[j])) // Si un martien est touch�
								{
									//Augmente notre nombre de Kill
									enemyKilled += 1;

									//D�truit le laser et le vaisseau
									martiens[i].detruire();
									lasers[j].detruire();
									lasers.erase(lasers.begin() + j);

									//Mettre � jour le score affich�
									score += (pointValue * difficultyScore);
									UpdateScore(score, coord);
									Sleep(1);
								}
							}
						}
					}

					//D�placer les lasers du vaisseau et des extraterrestres
					if (moveLasers) {
						for (int i = 0; i < lasers.size(); i++)
						{
							if (lasers[i].isActif()) {
								lasers[i].deplacer();
							}
						}
					}
					//V�rifie la collision entre notre laser et le laser Enemy 
					for (int i = 0; i < lasers.size(); i++)
					{
						for (int j = 0; j < lasersEnemy.size(); j++)
						{
							if (lasers[i].detecterCollision(lasersEnemy[j])) //Si il y a une collision, les 2 lasers se d�truisent
							{
								//D�truit lasers enemy
								lasersEnemy[j].detruire();
								lasersEnemy.erase(lasersEnemy.begin() + j);

								//D�truit notre laser
								lasers[i].detruire();
								lasers.erase(lasers.begin() + i);
							}
						}
					}
					//D�place le tir enemy
					if (moveLasers) {
						for (int i = 0; i < lasersEnemy.size(); i++)
						{
							if (lasersEnemy[i].isActif()) { //Si le laser enemy est actif
								lasersEnemy[i].deplacer();
							}
						}
					}
					//D�placer les extraterrestres
										//Faire apparaitre nouveau extraterrestre
					if (clock() - start >= (3000 * difficultyTime)) //Temps entre les spawns
					{
						start = clock(); //Restart la clock
						Coord enemyPosition(rand() % (POSITION_X_MAX - POSITION_X_MIN + 1) + POSITION_X_MIN, rand() % (POSITION_Y_MAX - POSITION_Y_MIN) + POSITION_Y_MAX); //Fais spawn un martien al�atoire
						Martien martien(enemyPosition, apparenceDesEnnemis, pointValue);
						martiens.push_back(martien);

						for (int i = 0; i < martiens.size(); i++)
						{
							if (martiens[i].isActif())
							{
								martiens[i].deplacer();
							}
						}
					}
					else if (clock() - enemyClock >= (1500 * difficultyTime)) // temps entre les tirs
					{
						enemyClock = clock(); //restart la clock des enemy
						bool didShoot = false;
						//Faire tirer un extraterrestre au hasard
						while (!didShoot) {
							int i = rand() % (martiens.begin(), martiens.size()); //Choisi un martiens au hasard 
							if (martiens[i].isActif()) { //V�rifie si il est actif
								//Fait tirer le martien
								Laser laser(martiens[i].getCoord(), TypeLaser::EXTRATERRESTRE);
								lasersEnemy.push_back(laser);
								didShoot = true;
							}
						}
					}
					//Fait avancer les enemy
					if (clock() - ennemyFoward >= (3000 * difficultyTime)) {
						ennemyFoward = clock(); //Restart la clock de l'avancement des enemy
						for (int i = 0; i < martiens.size(); i++) {
							if (martiens[i].isActif()) { //V�rifie si le martien est actif
								martiens[i].foward();
							}
						}
					}

					//V�rifie si on a �t� touch�
					for (int i = 0; i < lasersEnemy.size(); i++)
					{
						if (vaisseau.detecterCollision(lasersEnemy[i]))
						{
							partieTermine = true; //Termine la partie
						}
					}

					moveLasers = !moveLasers;

					Sleep(100);
				}

				//V�rifier si on gagne (si le nombre d'extraterrestre est rendu � 0)
				if (checkEnnemy(martiens))
				{
					partieTermine = true;
					partieGagne = true;
				}
				//V�rifier si on perd (si le nombre d'extra terrestre est � 15+ )
				if (martiens.size() >= (15 + enemyKilled))
				{
					partieTermine = true;
				}

				//Si le martien atteint notre position
				if (ennemyToFar(martiens, vaisseau)) {
					partieTermine = true;
				}

			} while (partieTermine == false);

			system("cls");
			if (gameLoop) {
				if (partieTermine == true && partieGagne == false) { //Si on gagne
					cout << "La partie est terminer\n\nVous avez perdu :(\n\nScore : " << score << endl;
					system("pause");
				}
				else { //si on perd
					score *= 2;
					cout << "La partie est terminer\n\nVous avez Gagnez :)\n\nScore : " << score << endl;
					system("pause");
				}

				//Si on d�passe le highscore
				if (highScore < score) {
					switch (choix)
					{
					case 1:
						highScore = score;
						highScoreDifficulty = EASY;
						break;
					case 2:
						highScore = score;
						highScoreDifficulty = MEDIUM;
						break;
					case 3:
						highScore = score;
						highScoreDifficulty = HARD;
						break;
					default:
						break;
					}
				}
			}
		}

	}
}
//Check si le martien est actif
bool checkEnnemy(vector<Martien> vec)
{
	for (int i = 0; i < vec.size(); i++) {
		if (vec[i].isActif()) {
			return false;
		}
	}
	return true;
}

//Updates the players score
void UpdateScore(int score, COORD coord)
{
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
	cout << score;
}

int iValidation() //FONCTION POUR V�RIFIER LA DONN�E ENTR�E
{
	int id{ 0 };
	cin >> id;
	while (cin.fail() || cin.peek() != '\n' || id > 4 || id < 1)
	{
		cin.clear();
		cin.ignore();
		cout << "Valeur non valide, veuillez recommencer.\n";
		cout << "--> ";
		cin >> id;
	}
	return id;
}
//Fonction qui v�rifie si le martien nous a atteint
bool ennemyToFar(vector<Martien> vec, Vaisseau vaisseau) {
	for (int i = 0; i < vec.size(); i++) {
		if (vec[i].getCoord().getY() == vaisseau.getCoord().getY()) {
			return true;
		}
	}
	return false;
}
//Fonction qui peut mettre en pause
void PAUSE(COORD pause, string GAME_PAUSED, string GAME_UNPAUSED, string PRESS_ENTER, string PRESS_ENTER_EXIT, COORD cExit) {
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pause);
	cout << GAME_PAUSED;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), cExit);
	cout << PRESS_ENTER;
	cin.get();
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pause);
	cout << GAME_UNPAUSED;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), cExit);
	cout << PRESS_ENTER_EXIT;
}