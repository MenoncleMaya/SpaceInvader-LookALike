

#include "Extraterrestes.h"
#include "UIKit.h"
#include <iostream>
Extraterrestes::Extraterrestes(Coord coord, char apparence, unsigned short valeurPoints) : ObjetDeJeu(coord, TypeObjetDeJeu::EXTRATERRESTRE), apparence(apparence), valeurPoints(valeurPoints) {
	this->afficher();
}

void Extraterrestes::effacer() {
	UIKit::gotoXY(this->coord.getX(), this->coord.getY());
	std::cout << " ";
}

void Extraterrestes::afficher() {
	UIKit::gotoXY(this->coord.getX(), this->coord.getY());
	std::cout << this->apparence;
}

unsigned short Extraterrestes::getValeurPoints() const
{
	return this->valeurPoints;
}
