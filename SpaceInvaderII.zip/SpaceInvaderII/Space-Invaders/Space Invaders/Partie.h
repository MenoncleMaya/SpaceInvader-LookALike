#pragma once

class Partie
{
public:
	void debuter();
};
